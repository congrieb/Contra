﻿using UnityEngine;
using System.Collections;

public class PE_Bullet : PE_Obj {
	public float speed = 8f;
}